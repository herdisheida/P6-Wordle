from Bucket import Bucket


class HashMap:

    def __init__(self):
        self.item_count = 0  # num of items in the entire data structure
        self.bucket_count = 8  # num of buckets (list capacity)

        self.bucket_list = [Bucket() for _ in range(self.bucket_count)]

    def insert(self, key, data):
        """Adds a new key-value pair."""
        self.rebuild()
        self.bucket_list[self._get_bucket_index(key)].insert(key, data)
        self.item_count += 1

    def update(self, key, data):
        """Updates existing key-value pair"""
        self.bucket_list[self._get_bucket_index(key)].update(key, data)

    def find(self, key):
        """Returns data value for a specific key"""
        return self.bucket_list[self._get_bucket_index(key)].find(key)

    def contains(self, key):
        """Returns True if if key is found in the collection, otherwise False"""
        return self.bucket_list[self._get_bucket_index(key)].contains(key)

    def remove(self, key):
        """Removes the value pair with equal key from the collection"""
        self.bucket_list[self._get_bucket_index(key)].remove(key)
        self.item_count -= 1

    def __setitem__(self, key, data):
        """Allows: some_hash_map[key] = data"""
        index = self._get_bucket_index(key)
        if self.contains(key):
            self.bucket_list[index][key] = data
        else:
            self.insert(key, data)

    def __getitem__(self, key):
        """Allows: my_data = some_hash_map[key"""
        return self.find(key)

    def __len__(self):
        """Returns the number of items in the entire data structure"""
        return self.item_count

    def rebuild(self):
        """When the num of items in the HashMap reach 120% of the num of buckets,
        Double the arrays capacity and redistributes all key-value pairs"""
        if self.item_count >= self.bucket_count * 1.2:
            old_bucket_list = self.bucket_list

            self.bucket_count *= 2
            self.bucket_list = [Bucket() for _ in range(self.bucket_count)]
            self.item_count = 0  # reset before redistributing

            for bucket in old_bucket_list:
                node = bucket.head
                while node:
                    self.insert(node.key, node.data)
                    node = node.next

    def _get_bucket_index(self, key):
        """Get bucket index according to key"""
        return hash(key) % self.bucket_count