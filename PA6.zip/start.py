from ui_layer.GameMenu import GameMenu

if __name__ == "__main__":
    game = GameMenu()
    game.run()
